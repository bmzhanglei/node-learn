'use strict';

const Service = require('egg').Service;

class NewsService extends Service {
  async echo() {
    
  }
}

module.exports = NewsService;

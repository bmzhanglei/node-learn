'use strict';

const Controller = require('egg').Controller;

class MainController extends Controller {
  async index() {
    /*
           1、获取当前登录用户的角色
           
           2、获取全部的权限  
  
           3、查询当前角色拥有的权限（查询当前角色的权限id） 把查找到的数据放在数组中
  
           4、循环遍历所有的权限数据     判断当前权限是否在角色权限的数组中，   如果在角色权限的数组中：显示

           5、如果是超级管理员显示所有菜单

         
          
           
  */

    // 1、获取当前登录用户的角色
    let roleId = this.ctx.session.userinfo.roleId;
    let isSuper = this.ctx.session.userinfo.isSuper;
    
    // 2、获取全部的权限  
    let allAuthResult = await this.ctx.model.Access.findAll({
      where: {
        moduleId: 0
      },
      include: { model: this.ctx.model.Access }
    });

    // 3、查询当前角色拥有的权限（查询当前角色的权限id） 把查找到的数据放在数组中
    let tempArr = [];
    let roleAuthResult = await this.ctx.model.RoleAccess.findAll({
      where: {
        roleId: roleId
      }
    });
    for (let i = 0; i < roleAuthResult.length; i++) {
      tempArr.push(roleAuthResult[i].accessId);
    }

    // 4、循环遍历所有的权限数据     判断当前权限是否在角色权限的数组中，   如果在角色权限的数组中：选中    如果不在角色权限的数组中不选中

    //注意：把不可改变的对象改为可改变的对象
    allAuthResult = JSON.parse(JSON.stringify(allAuthResult));
    for (let i = 0; i < allAuthResult.length; i++) {
      if (tempArr.indexOf(allAuthResult[i].id) != -1) {
        allAuthResult[i].checked = true;
      }
      for (let j = 0; j < allAuthResult[i].accesses.length; j++) {
        if (tempArr.indexOf(allAuthResult[i].accesses[j].id) != -1) {
          allAuthResult[i].accesses[j].checked = true;
        }
      }
    }

    // this.ctx.body=allAuthResult;
    await this.ctx.render("admin/main/index",{
      authList: allAuthResult,
      isSuper:isSuper
    })
  }
  async welcome() {
    await this.ctx.render("admin/main/welcome")
  }

  async changeStatus() {
    let model = this.ctx.request.query.model; /*数据库表 Model  Product*/ 
    let field = this.ctx.request.query.field; /*更新的字段 如:status   is_best */     
    let id = this.ctx.request.query.id; /*更新的 id*/

    let modelObj=await this.ctx.model[model].findByPk(id);
    let json={};

    if(!modelObj){
      this.ctx.body={"success":false,"msg":"参数错误"};
      return;
    }else{

      if(modelObj[field]==1){
        json={  /*es6 属性名表达式 注意作作用域*/
          [field]:0
        }
      }else{
        json={
          [field]:1
        }
      }

      await modelObj.update(json);

      this.ctx.body={"success":true,"msg":"更新数据成功"};


    }


   
  }
}

module.exports = MainController;

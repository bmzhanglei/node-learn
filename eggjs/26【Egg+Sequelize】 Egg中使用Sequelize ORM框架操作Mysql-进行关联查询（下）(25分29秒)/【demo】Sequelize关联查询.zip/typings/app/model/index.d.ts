// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportArticle = require('../../../app/model/article');
import ExportArticleCate = require('../../../app/model/article_cate');
import ExportLesson = require('../../../app/model/lesson');
import ExportLessonStudent = require('../../../app/model/lesson_student');
import ExportStudent = require('../../../app/model/student');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Article: ReturnType<typeof ExportArticle>;
    ArticleCate: ReturnType<typeof ExportArticleCate>;
    Lesson: ReturnType<typeof ExportLesson>;
    LessonStudent: ReturnType<typeof ExportLessonStudent>;
    Student: ReturnType<typeof ExportStudent>;
    User: ReturnType<typeof ExportUser>;
  }
}

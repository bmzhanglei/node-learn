'use strict';

const Controller = require('egg').Controller;

class V1Controller extends Controller {
    async index() {
        this.ctx.body = {
            "result": "无人点餐系统api接口",
            "success": true
        }
    }
    async productList() {
        let result = await this.ctx.model.ProductCate.findAll({
            include: {
                model: this.ctx.model.Product,
                attributes: ["id", "cid", "title", "price", "imgUrl", "sort"]
            },
            order: [
                ['sort', 'DESC'],
                [this.ctx.model.Product, 'sort', 'DESC'],
            ],
        });
        this.ctx.body = {
            "result": result,
            "success": true
        }

    }

    async productContent() {
        let id = this.ctx.request.query.id;
        let result = await this.ctx.model.Product.findAll({
            where: {
                id: id
            }
        })
        if (result.length > 0) {
            this.ctx.body = {
                "result": result,
                "success": true
            }
        } else {
            this.ctx.body = {
                "result": [],
                "success": false
            }
        }

    }
    /*
    增加购物车接口  
      1、判断购物车是否有当前桌号对应的菜品数据
      2、没有的话执行增加
      3、有的话执行修改  让数量加1  
    */
    async addCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            this.ctx.model.Cart.update({
                productNum: cartResult[0].productNum + 1
            }, {
                where: {
                    tableId: tableId,
                    productId: productId
                }
            });
        } else {
            await this.ctx.model.Cart.create({
                ...body,
                addTime: this.ctx.service.tools.getUnixTime(),
            });
        }

        this.ctx.body = { "success": 'true', "msg": "增加数据成功" };
    }
    //购物车列表
    async cartList() {
        try {
            let tableId = this.ctx.request.query.tableId;
            let cartResult = await this.ctx.model.Cart.findAll({
                where: {
                    tableId: tableId
                }
            })
            this.ctx.body = { "success": true, "result": cartResult };

        } catch (error) {
            this.ctx.body = { "success": false, "result": [] };
        }

    }
    // 增加购物车数量
    async incCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            this.ctx.model.Cart.update({
                productNum: cartResult[0].productNum + 1
            }, {
                where: {
                    tableId: tableId,
                    productId: productId
                }
            });
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            this.ctx.body = { "success": false, "msg": "更新失败" };
        }



    }
    // 增加减少购物车数量
    async decCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            if (cartResult[0].productNum > 1) {
                this.ctx.model.Cart.update({
                    productNum: cartResult[0].productNum - 1
                }, {
                    where: {
                        tableId: tableId,
                        productId: productId
                    }
                });
            } else {
                this.ctx.model.Cart.destroy({
                    where: {
                        tableId: tableId,
                        productId: productId
                    }
                });
            }
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            this.ctx.body = { "success": false, "msg": "更新失败" };
        }
    }
    //获取购物车总数量
    async cartCount() {
        try {
            let tableId = this.ctx.request.query.tableId;

            let count = await this.ctx.model.Cart.sum(
                "productNum",
                { where: { tableId: tableId } }
            )
            count = count ? count : 0;
            this.ctx.body = { "success": true, count: count };

        } catch (error) {
            this.ctx.body = { "success": false, count: 0 };
        }
    }

    //获取口味信息
    async flavorList() {
        let result = await this.ctx.model.Setting.findAll();
        //少辣，不要葱，打包带走   ["少辣","不要葱"]
        let list = result[0].orderLabel.replace("，", ",").split(",");
        this.ctx.body = { "success": true, result: list };
    }

    //增加修改用户用餐信息
    async addPeopleInfo() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let result = await this.ctx.model.PeopleInfo.findAll({
            where: {
                tableId: tableId,
            }
        })
        if (result.length > 0) {
            await this.ctx.model.PeopleInfo.update(body, {
                where: {
                    tableId: tableId
                }
            })
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            await this.ctx.model.PeopleInfo.create(body);
            this.ctx.body = { "success": true, "msg": "更新成功" };
        }
    }
    // 获取用户用餐信息
    async getPeopleInfo() {
        try {
            let tableId = this.ctx.request.query.tableId;
            let result = await this.ctx.model.PeopleInfo.findAll({
                where: {
                    tableId: tableId
                }
            })
            if (result.length > 0) {
                this.ctx.body = { "success": true, result: result[0] };
            } else {
                this.ctx.body = { "success": true, result: [] };
            }

        } catch (error) {
            this.ctx.body = { "success": false, result: [] };
        }
    }

    /*
    增加订单接口：
        1、获取数据 并解析orderItem
        2、判断当前桌子下面是否有已下单并且未支付的订单，如果有的话更新订单，没有执行增加
        3、清空当前桌子对应的购物车数据
        4、打印小票
    */
    async addOrder() {
        let body = this.ctx.request.body;

        let tableId=body.tableId;
        let pNum=body.pNum;    //用餐人数
        let pMark=body.pMark;  //备注口味信息
        let orderItems=  body.orderItems?JSON.parse(body.orderItems):[];  //菜品信息
        let orderId=this.service.tools.getOrderId();   ///  //生成orderId
        let totalPrice=body.totalPrice;  //总价格
        let totalNum=body.totalNum;      //总数量        
        let payStatus=0;   //0表示未支付  1表示已经支付
        let orderStatus=0; //0表示已 下单并且未支付        1 表示已支付 已完结     2表示取消
        let addTime=this.service.tools.getUnixTime();  //增加日期


        let orderResult=await this.ctx.model.Order.findAll({
            where:{
                tableId:tableId,
                payStatus:0,
                orderStatus:0
            }
        })
        if(orderResult.length>0){  //合并订单
            await this.ctx.model.Order.update({
                totalPrice:Number(totalPrice)+Number(orderResult[0].totalPrice),
                totalNum:Number(totalNum)+Number(orderResult[0].totalNum),
            },{
                where:{
                    tableId:tableId,
                    payStatus:0,
                    orderStatus:0
                }
            })

            for (let i = 0; i < orderItems.length; i++) {
                await this.ctx.model.OrderItems.create({
                    orderId:  orderResult[0].id,
                    tableId:tableId,
                    productId:orderItems[i].productId,
                    productImg:orderItems[i].productImg,
                    productTitle:orderItems[i].productTitle,
                    productPrice:orderItems[i].productPrice,
                    productNum:orderItems[i].productNum,
                    status:1    /*状态是1  表示已经下厨     状态是2表示退菜*/
                })                
            }


        }else{  //增加订单

            //1、增加order表的数据
            let orderCreateResult=await this.ctx.model.Order.create({
                tableId,
                pNum,
                pMark,
                orderId,
                totalPrice,
                totalNum,
                payStatus,
                orderStatus,
                addTime      
            })
            console.log(orderCreateResult);
            //2、增加order_item表的数据
            if(orderCreateResult){
                for (let i = 0; i < orderItems.length; i++) {
                    await this.ctx.model.OrderItems.create({
                        orderId:  orderCreateResult.id,
                        tableId:tableId,
                        productId:orderItems[i].productId,
                        productImg:orderItems[i].productImg,
                        productTitle:orderItems[i].productTitle,
                        productPrice:orderItems[i].productPrice,
                        productNum:orderItems[i].productNum,
                        status:1    /*状态是1  表示已经下厨     状态是2表示退菜*/
                    })                
                }
            }

        }

        this.ctx.body = { "success": true, "msg": "增加订单成功" };
    }
    //获取订单信息
    async getOrder() {
        let tableId = this.ctx.request.query.tableId;
        let result = await this.ctx.model.Order.findAll({
            include:{
                model:this.ctx.model.OrderItems
            },
            where: {
                tableId: tableId
            }
        })
        this.ctx.body = {
            "result": result,
            "success": true
        }
    }


    async login() {
        // this.ctx.body="login";

        const token = this.app.jwt.sign({ foo: 'bar' }, this.app.config.jwt.secret,{
            expiresIn:60*60*2
        });
        this.ctx.body={
            "success":true,
            "token":token
        }

    }


}

module.exports = V1Controller;

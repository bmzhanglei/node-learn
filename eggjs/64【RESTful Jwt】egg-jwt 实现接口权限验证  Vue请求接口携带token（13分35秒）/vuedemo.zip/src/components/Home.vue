<template>
  <div class="home">
    <button @click="getProductData()">获取菜品数据</button>
    <br />
    <br />
    <button @click="addCart()">购物车增加数据</button>

    <br />
    <br />
    <button @click="getCartList()">获取购物车数据</button>
    <br />
    <br />

    <button @click="incCart()">增加购物车数量</button>

    <br />
    <br />

    <button @click="decCart()">减少购物车数量</button>

    <br />
    <br />

    <button @click="cartCount()">统计购物车数量</button>

    <br />
    <br />
    <button @click="flavorList()">获取口味信息</button>
    <br />
    <br />

    <button @click="addPeopleInfo()">增加/修改用餐人数信息</button>
    <br />
    <br />

    <button @click="getPeopleInfo()">获取用餐信息</button>

    <br />
    <br />

    <button @click="addOrder()">提交订单</button>

    <br />
    <br />

    <button @click="getOrder()">获取订单</button>

    <br />
    <br />

    <button @click="doLogin()">Jwt验证Login</button>

    <br />
    <br />

    <button @click="getIndex()">先执行Login获取token才可以请求接口传入token</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
      token: "",
    };
  },
  methods: {
    getProductData() {
      var api = "http://localhost:7001/api/v1/productList";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    addCart() {
      var api = "http://localhost:7001/api/v1/addCart";
      this.Axios.post(api, {
        productTitle: "手撕包菜",
        tableId: 10,
        imgUrl: "www.itying.com",
        productPrice: 12,
        productNum: 1,
        productId: 12,
      })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getCartList() {
      var api = "http://localhost:7001/api/v1/cartList?tableId=12";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    incCart() {
      var api = "http://localhost:7001/api/v1/incCart";
      this.Axios.put(api, { productId: 12, tableId: 10 })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    decCart() {
      var api = "http://localhost:7001/api/v1/decCart";
      this.Axios.put(api, { productId: 12, tableId: 10 })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    cartCount() {
      var api = "http://localhost:7001/api/v1/cartCount?tableId=10";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    flavorList() {
      var api = "http://localhost:7001/api/v1/flavorList";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    addPeopleInfo() {
      var api = "http://localhost:7001/api/v1/addPeopleInfo";
      this.Axios.post(api, {
        tableId: 12,
        pNum: 4,
        pMark: "不要辣椒",
      },{
        headers: {
          Authorization: "Bearer " + this.token,
        },
      })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getPeopleInfo() {
      var api = "http://localhost:7001/api/v1/getPeopleInfo?tableId=10";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // /api/v1/addOrder

    addOrder() {
      var orderItems = [
        {
          productId: 1,
          productImg: "/image/a.png",
          productTitle: "拍黄瓜",
          productPrice: 22,
          productNum: 1,
        },
        {
          productId: 2,
          productImg: "/image/a.png",
          productTitle: "娃娃菜炖豆腐",
          productPrice: 18,
          productNum: 1,
        },
      ];
      var api = "http://localhost:7001/api/v1/addOrder";
      this.Axios.post(api, {
        tableId: 18,
        pNum: 5,
        pMark: "不要辣椒",
        orderItems: JSON.stringify(orderItems),
        totalPrice: 100,
        totalNum: 2,
      })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getOrder() {
      var api = "http://localhost:7001/api/v1/getOrder?tableId=12";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    doLogin() {
      var api = "http://localhost:7001/api/v1/login";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
          this.token = response.data.token;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getIndex() {
      var api = "http://localhost:7001/api/v1";
      this.Axios.get(api, {
        headers: {
          Authorization: "Bearer " + this.token,
        },
      })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
};
</script>

<style lang="scss">
.home {
  padding: 20px;
}
</style>

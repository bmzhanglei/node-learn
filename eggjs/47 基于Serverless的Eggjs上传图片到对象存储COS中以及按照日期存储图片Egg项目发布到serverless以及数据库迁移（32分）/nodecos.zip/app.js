const COS = require('cos-nodejs-sdk-v5');
const fs=require("fs");
//配置cos的sdk  https://console.cloud.tencent.com/cam/capi
var cos = new COS({
    SecretId: 'AKID5ve8OOxxxxxTP6XiEUUFkhVJMvG',
    SecretKey: 'GF2KOnwoSxxxNmGWWwfS0IqAJE'
});

//上传本地图片到对象云存储里面
cos.putObject({
    Bucket: 'expressitying-1251179943', /* 必须存储桶名称 */
    Region: 'ap-guangzhou',    /* 必须 区域*/
    Key: 'itying.png',              /* 必须   目录/文件的名称  */
    StorageClass: 'STANDARD',
    Body: fs.createReadStream('./a.png'), // 上传文件对象
    onProgress: function(progressData) {
        console.log(JSON.stringify(progressData));
    }
}, function(err, data) {
    console.log(err || data);
});
'use strict';
// Sequelize数据类型  http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6
module.exports = app => {
  const { STRING, INTEGER, DECIMAL } = app.Sequelize;
  const Order = app.model.define('order', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    orderId:STRING(255),  
    tableId:INTEGER(11),
    totalPrice:DECIMAL(10,2),
    totalNum:INTEGER(11),
    pNum:INTEGER(11),
    pMark:STRING(255), 
    payStatus:INTEGER(1),   // 0表示未支付        1表示已经支付
    payType:INTEGER(1),     // 1 支付宝支付       2微信支付
    orderStatus:INTEGER(1), // 0表示已下单并且未支付        1 表示已支付 已完结     2表示取消
    addTime:INTEGER(11)
  }, {
    timestamps: false, //自动增加创建时间 
    tableName: 'order' //设置表名称
  });

  Order.associate = function (){ // 1 对 多    
    app.model.Order.hasMany(app.model.OrderItems, {foreignKey: 'orderId'});
  }

  return Order;
};
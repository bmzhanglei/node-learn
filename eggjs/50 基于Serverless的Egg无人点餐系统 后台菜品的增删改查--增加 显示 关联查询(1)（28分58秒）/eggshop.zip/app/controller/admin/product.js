'use strict';

const Controller = require('egg').Controller;
const BaseController = require('./base.js');
const fs = require('mz/fs');

class ProductController extends BaseController {
    async index() {
        let result = await this.ctx.model.Product.findAll({
            include: { model: this.ctx.model.ProductCate }
        });        
        await this.ctx.render("admin/product/index",{
            list:result
        });

        //this.ctx.body = "菜品首页 请访问 product/add 实现图片上传 "
    }
    async add() {
        let result = await this.ctx.model.ProductCate.findAll();   
        await this.ctx.render("admin/product/add",{
            cateList:result
        })
    }

    //单文件上传
    async doAdd() {
        const { ctx } = this;
        const body = ctx.request.body;     
        const file = ctx.request.files[0];
        let title=body.title;
        if (title != "") {
            if (file) {
                var source = fs.createReadStream(file.filepath);
                var filename = this.ctx.service.tools.getCosUploadFile(file.filename);
    
                //异步 改成 同步
                await this.ctx.service.tools.uploadCos(filename, source);
            }
            await this.ctx.model.Product.create({
                ...body,
                ...{
                    imgUrl:file?filename:"",
                    status: 1,
                    addTime: this.ctx.service.tools.getUnixTime()
                }
            });
            await this.success("增加菜品成功", `/${this.config.adminPath}/product`);

        } else {
            await this.error("菜品名称不能为空", `/${this.config.adminPath}/product/add`);
        }
    }

    async doUpload() {
        const { ctx } = this;
        const body = ctx.request.body;
        //文件信息
        const file = ctx.request.files[0];

        if (file) {
            var source = fs.createReadStream(file.filepath);
            var filename = this.ctx.service.tools.getCosUploadFile(file.filename);

            //异步 改成 同步
            await this.ctx.service.tools.uploadCos(filename, source);
        }
       
        ctx.body = {link: this.config.cosUrl+"/"+filename};
    }


    //多文件上传
    // async doAdd() {
    //     const { ctx } = this;
    //     const body = ctx.request.body;
    //     //文件信息
    //     const files = ctx.request.files;
    //     try {
    //         for (let file of files) {
    //             //获取文件名称
    //             const filename = file.filename;
    //             //定义保存文件的目录
    //             // const targetPath = path.join('app/public/upload', filename);

    //             const targetPath =await this.ctx.service.tools.getUploadFile(filename);
    //             //读取文件
    //             const source = fs.createReadStream(file.filepath);
    //             //创建写入流
    //             const target = fs.createWriteStream(targetPath);
    //             await pump(source, target);
    //         }
    //     } finally {
    //         // delete those request tmp files
    //         await ctx.cleanupRequestFiles();
    //     }

    //     ctx.body = {
    //         body: body,
    //         files: files
    //     }
    // }
}

module.exports = ProductController;

'use strict';

const Controller = require('egg').Controller;

class V1Controller extends Controller {
    async index() {
       
        this.ctx.body = {
            "result": "无人点餐系统api接口",
            "success": true
        }
    }
    async productList() {
        let result = await this.ctx.model.ProductCate.findAll({
            include: {
                model: this.ctx.model.Product,
                attributes: ["id", "cid", "title", "price", "imgUrl", "sort"]
            },
            order: [
                ['sort', 'DESC'],
                [this.ctx.model.Product, 'sort', 'DESC'],
            ],
        });
        this.ctx.body = {
            "result": result,
            "success": true
        }

    }

    async productContent() {
        let id = this.ctx.request.query.id;
        let result = await this.ctx.model.Product.findAll({
            where: {
                id: id
            }
        })
        if (result.length > 0) {
            this.ctx.body = {
                "result": result,
                "success": true
            }
        }else{
            this.ctx.body = {
                "result": [],
                "success": false
            }
        }

    }

    async addCart() {
        console.log(this.ctx.request.body);
        this.ctx.body = this.ctx.request.body;
    }
}

module.exports = V1Controller;

// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuth = require('../../../app/middleware/auth');
import ExportCompress = require('../../../app/middleware/compress');
import ExportJsonp = require('../../../app/middleware/jsonp');

declare module 'egg' {
  interface IMiddleware {
    auth: typeof ExportAuth;
    compress: typeof ExportCompress;
    jsonp: typeof ExportJsonp;
  }
}

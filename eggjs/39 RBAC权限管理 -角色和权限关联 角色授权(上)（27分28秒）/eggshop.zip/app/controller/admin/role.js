'use strict';

const BaseController = require('./base.js');
class RoleController extends BaseController {
    async index() {
        let result=await this.ctx.model.Role.findAll();
        console.log(result);
        await this.ctx.render("admin/role/index",{
            list:result
        })
    }
    async add() {
        await this.ctx.render("admin/role/add")
    }
    async doAdd() {  
        let title=this.ctx.request.body.title;
        if(title!=""){           
            await this.ctx.model.Role.create(Object.assign(this.ctx.request.body,{              
                status:1,
                addTime:this.ctx.service.tools.getUnixTime()
            }))
            await this.success("增加角色成功",`/${this.config.adminPath}/role`);
        }else{
            await this.error("角色名称不能为空",`/${this.config.adminPath}/role/add`)
        }
    }
    
    async edit() {
        try {
            let id=this.ctx.request.query.id;
            let result=await this.ctx.model.Role.findAll({
                where:{
                    id:id
                }
            });
            console.log(result[0].title);

            await this.ctx.render("admin/role/edit",{
                list:result[0]
            });
            
        } catch (error) {
            await this.error("非法请求",`/${this.config.adminPath}/role`);
        }
    }
    async doEdit() {      
        let id=this.ctx.request.body.id;
        let role=await this.ctx.model.Role.findByPk(id);
        if (!role) {
            await this.error("非法请求",`/${this.config.adminPath}/role/edit?id=${id}`);
            return;
        }
        await role.update(this.ctx.request.body);
        await this.success("修改数据成功",`/${this.config.adminPath}/role`);
        
    }
    async delete() {
        try {
            let id=this.ctx.request.query.id;
            let role=await this.ctx.model.Role.findByPk(id);
            if (!role) {
                await this.error("非法请求",`/${this.config.adminPath}/role/`);
                return;
            }
            await role.destroy();
            await this.success("删除数据成功",`/${this.config.adminPath}/role`);
        } catch (error) {
            await this.error("非法请求",`/${this.config.adminPath}/role`);
        }
        
    }
    async auth() {
        let roleId=this.ctx.request.query.id;
        let authResult = await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            },
            include: { model: this.ctx.model.Access }
        });

        console.log(authResult);
            
        await this.ctx.render("admin/role/auth",{
            authList:authResult,
            roleId:roleId
        });
    }
    async doAuth() {
        // this.ctx.body=this.ctx.request.body;
        let accessIds=this.ctx.request.body.accessIds;
        let roleId=this.ctx.request.body.roleId;

        //1、删除当前角色对应的权限数据

        await this.ctx.model.RoleAccess.destroy({
            where:{
                roleId:roleId
            }
        })
        //2、把当前角色对应的权限增加到 数据库表里面        
        for(var i=0;i<accessIds.length;i++){
            await this.ctx.model.RoleAccess.create({
                roleId:roleId,
                accessId:accessIds[i]
            })
        }
        await this.success("授权成功",`/${this.config.adminPath}/role/auth/?id=${roleId}`);
    }
    
    
   
}

module.exports = RoleController;

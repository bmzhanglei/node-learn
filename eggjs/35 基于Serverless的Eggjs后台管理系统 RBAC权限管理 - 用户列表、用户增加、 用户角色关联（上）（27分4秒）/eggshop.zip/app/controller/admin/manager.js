'use strict';

const BaseController = require('./base.js');

class ManagerController extends BaseController {
  async index() {  
    let result = await this.ctx.model.Admin.findAll({ 
      include: { model: this.ctx.model.Role } 
    });
    console.log(result[1].role.title);
    await this.ctx.render("admin/manager/index",{
      list:result
    })
  }
  async add() {    
    //获取角色
    let roleList=await this.ctx.model.Role.findAll();
    await this.ctx.render("admin/manager/add",{
      roleList:roleList
    })
  }
  async doAdd() {
    //1、获取表单穿过来的数据
    let addResult=this.ctx.request.body;
    //2、验证数据是否合成  前端js  后端验证
    if (addResult.username==""){
      await this.error("管理员名称不能为空",`/${this.config.adminPath}/manager/add`);
      return;
    }
    if (addResult.password.length<6){
      await this.error("管理员的密码不能小于6位",`/${this.config.adminPath}/manager/add`);
      return;
    }
    //3、数据库表里面有没有当前用户
    let adminResult=await this.ctx.model.Admin.findAll({
      where:{
        username:addResult.username
      }
    })
    if(adminResult.length>0){
      await this.error("此管理员已经存在",`/${this.config.adminPath}/manager/add`);     
    }else{
      addResult.password=this.ctx.service.tools.md5(addResult.password);
      await this.ctx.model.Admin.create({
        ...addResult,
        ...{
          addTime:this.ctx.service.tools.getUnixTime(),
          status:1,
          isSuper:0
        }
      })
      await this.success("增加管理员成功",`/${this.config.adminPath}/manager`);     
    }

    
  }
  async edit() {
    this.ctx.body="管理员 修改";
  }
  async delete() {
    this.ctx.body="管理员 删除";
  }
}
module.exports = ManagerController;

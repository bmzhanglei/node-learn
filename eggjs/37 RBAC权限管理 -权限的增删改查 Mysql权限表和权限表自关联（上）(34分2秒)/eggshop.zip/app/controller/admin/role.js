'use strict';

const BaseController = require('./base.js');
class RoleController extends BaseController {
    async index() {
        let result=await this.ctx.model.Role.findAll();
        console.log(result);
        await this.ctx.render("admin/role/index",{
            list:result
        })
    }
    async add() {
        await this.ctx.render("admin/role/add")
    }
    async doAdd() {  
        let title=this.ctx.request.body.title;
        if(title!=""){           
            await this.ctx.model.Role.create(Object.assign(this.ctx.request.body,{              
                status:1,
                addTime:this.ctx.service.tools.getUnixTime()
            }))
            await this.success("增加角色成功",`/${this.config.adminPath}/role`);
        }else{
            await this.error("角色名称不能为空",`/${this.config.adminPath}/role/add`)
        }
    }
    
    async edit() {
        try {
            let id=this.ctx.request.query.id;
            let result=await this.ctx.model.Role.findAll({
                where:{
                    id:id
                }
            });
            console.log(result[0].title);

            await this.ctx.render("admin/role/edit",{
                list:result[0]
            });
            
        } catch (error) {
            await this.error("非法请求",`/${this.config.adminPath}/role`);
        }
    }
    async doEdit() {      
        let id=this.ctx.request.body.id;
        let role=await this.ctx.model.Role.findByPk(id);
        if (!role) {
            await this.error("非法请求",`/${this.config.adminPath}/role/edit?id=${id}`);
            return;
        }
        await role.update(this.ctx.request.body);
        await this.success("修改数据成功",`/${this.config.adminPath}/role`);
        
    }
    async delete() {
        try {
            let id=this.ctx.request.query.id;
            let role=await this.ctx.model.Role.findByPk(id);
            if (!role) {
                await this.error("非法请求",`/${this.config.adminPath}/role/`);
                return;
            }
            await role.destroy();
            await this.success("删除数据成功",`/${this.config.adminPath}/role`);
        } catch (error) {
            await this.error("非法请求",`/${this.config.adminPath}/role`);
        }
        
    }
}

module.exports = RoleController;

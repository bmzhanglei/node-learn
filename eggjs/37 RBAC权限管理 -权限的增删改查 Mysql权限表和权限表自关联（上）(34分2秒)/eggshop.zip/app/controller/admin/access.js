'use strict';

const BaseController = require('./base.js');

class AccessController extends BaseController {
    async index() {
        // this.ctx.body = "权限列表";

        let result = await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            },
            include: { model: this.ctx.model.Access }
        });
        // this.ctx.body=result;
        await this.ctx.render("admin/access/index",{
            list:result
        });    
    }
    async add() {
        //获取moduleId=0的模块
        let accessList=await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            }
        })
        // console.log(accessResult);
        await this.ctx.render("admin/access/add",{
            accessList:accessList
        });       
    }
    async doAdd() {
        let addResult=this.ctx.request.body;
        if(addResult.moduleName==""){
            await this.error("模块名称不能为空",`/${this.config.adminPath}/access/add`);
            return;
        }
        await this.ctx.model.Access.create({
            ...addResult,
            status:1,
            addTime:this.ctx.service.tools.getUnixTime()
        })

        await this.success("增加权限成功",`/${this.config.adminPath}/access`);
    }
    async edit() {
        this.ctx.body = "权限 修改";
    }
    async delete() {
        this.ctx.body = "权限 删除";
    }
}

module.exports = AccessController;

module.exports = (options) => {
    return async function adminAuth(ctx,next){    
        ctx.state.csrf=ctx.csrf; //全局变量
        ctx.state.adminPath=options.adminPath;  //获取配置文件里面的后台地址  
        let pathname=ctx.request.url;
        pathname=pathname.split("?")[0];    //  /admin/login/captcha?mt=0.7606638325121275     
        if(ctx.session.userinfo && ctx.session.userinfo.username){

            var hasAuth=await ctx.service.admin.checkAuth();
            if(hasAuth){
                ctx.state.userinfo=ctx.session.userinfo;
                await next();
            }else{
                ctx.body="您没有权限访问这个地址";
            }
        }else{
            //排除权限判断的页面
            if(pathname==`/${options.adminPath}/login` || pathname==`/${options.adminPath}/doLogin` || pathname==`/${options.adminPath}/login/captcha`){
                await next();
            }else{
                ctx.redirect(`/${options.adminPath}/login`);
            }           
        }
        // await next();
    }
}
<template>
<div class="home">
    <button @click="getData()">Axios获取数据</button>
    <br>
     <br>
    <button @click="setData()">Axios提交数据</button>
</div>
</template>

<script>
export default {
    data() {
        return {
            list: [],

        }
    },
    methods: {
        getData() {
            // http://www.phonegap100.com/appapi.php?a=getPortalList&catid=20&page=1
            var api = "http://localhost:7001/api/v1";
            this.Axios.get(api).then((response) => {
                console.log(response.data);
            }).catch((err) => {
                console.log(err)
            })
        },setData(){
            var api = "http://localhost:7001/api/v1/addCart";
            this.Axios.post(api,{"title":"娃娃菜","price":20}).then((response) => {
                console.log(response.data);
            }).catch((err) => {
                console.log(err)
            })
        }
    }  
}
</script>

<style lang="scss">
.home {
    padding: 20px;
}
</style>

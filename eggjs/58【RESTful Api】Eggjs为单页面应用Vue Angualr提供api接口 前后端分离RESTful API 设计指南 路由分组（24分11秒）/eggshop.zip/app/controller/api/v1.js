'use strict';

const Controller = require('egg').Controller;

class V1Controller extends Controller {
    async index() {
        let result=await this.ctx.model.Product.findAll();
        this.ctx.body = {
            "result": result,
            "success":true
        }
    }

    async addCart() {
       console.log(this.ctx.request.body);
       this.ctx.body=this.ctx.request.body;
    }
}

module.exports = V1Controller;

module.exports = (options) => {
    return async function adminAuth(ctx,next){    
        ctx.state.csrf=ctx.csrf; //全局变量
        
        let pathname=ctx.request.url;
        pathname=pathname.split("?")[0];    //  /admin/login/captcha?mt=0.7606638325121275     
        if(ctx.session.userinfo && ctx.session.userinfo.username){
            await next();
        }else{
            //排除权限判断的页面
            if(pathname=="/admin/login" || pathname=="/admin/doLogin" || pathname=="/admin/login/captcha"){
                await next();
            }else{
                ctx.redirect("/admin/login");
            }
           
        }
    }
}
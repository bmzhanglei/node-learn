'use strict';

const Controller = require('egg').Controller;

class ManagerController extends Controller {
  async index() {  
    this.ctx.session.username={
      username:"张三",
      age:20
    };
    await this.ctx.render("admin/manager/index",{})
  }
  async add() {
    this.ctx.body=this.ctx.session.username;
    // await this.ctx.render("admin/manager/add",{})
  }
  async edit() {
    this.ctx.body="管理员 修改";
  }
  async delete() {
    this.ctx.body="管理员 删除";
  }
}

module.exports = ManagerController;

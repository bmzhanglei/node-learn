'use strict';

const Controller = require('egg').Controller;
class LoginController extends Controller {
  async index() {
    await this.ctx.render("admin/login")
  }
  async captcha() {
    
    let captcha = await this.service.tools.getCaptcha();
    console.log(captcha.text);
    this.ctx.session.code=captcha.text;
    this.ctx.response.type = 'image/svg+xml'; /*指定返回的类型*/ 
    this.ctx.body = captcha.data; /*给页面返回一张图片*/

  }
}

module.exports = LoginController;

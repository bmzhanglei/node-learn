'use strict';

const Controller = require('egg').Controller;

class V1Controller extends Controller {
    async index() {
        this.ctx.body = {
            "result": "无人点餐系统api接口",
            "success": true
        }
    }
    async productList() {
        let result = await this.ctx.model.ProductCate.findAll({
            include: {
                model: this.ctx.model.Product,
                attributes: ["id", "cid", "title", "price", "imgUrl", "sort"]
            },
            order: [
                ['sort', 'DESC'],
                [this.ctx.model.Product, 'sort', 'DESC'],
            ],
        });
        this.ctx.body = {
            "result": result,
            "success": true
        }

    }

    async productContent() {
        let id = this.ctx.request.query.id;
        let result = await this.ctx.model.Product.findAll({
            where: {
                id: id
            }
        })
        if (result.length > 0) {
            this.ctx.body = {
                "result": result,
                "success": true
            }
        } else {
            this.ctx.body = {
                "result": [],
                "success": false
            }
        }

    }
    /*
    增加购物车接口  
      1、判断购物车是否有当前桌号对应的菜品数据
      2、没有的话执行增加
      3、有的话执行修改  让数量加1  
    */
    async addCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            this.ctx.model.Cart.update({
                productNum: cartResult[0].productNum + 1
            }, {
                where: {
                    tableId: tableId,
                    productId: productId
                }
            });
        } else {
            await this.ctx.model.Cart.create({
                ...body,
                addTime: this.ctx.service.tools.getUnixTime(),
            });
        }

        this.ctx.body = { "success": 'true', "msg": "增加数据成功" };
    }
    //购物车列表
    async cartList() {
        try {
            let tableId = this.ctx.request.query.tableId;
            let cartResult = await this.ctx.model.Cart.findAll({
                where: {
                    tableId: tableId
                }
            })
            this.ctx.body = { "success": true, "result": cartResult };

        } catch (error) {
            this.ctx.body = { "success": false, "result": [] };
        }

    }
    // 增加购物车数量
    async incCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            this.ctx.model.Cart.update({
                productNum: cartResult[0].productNum + 1
            }, {
                where: {
                    tableId: tableId,
                    productId: productId
                }
            });
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            this.ctx.body = { "success": false, "msg": "更新失败" };
        }



    }
    // 增加减少购物车数量
    async decCart() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let productId = body.productId;
        let cartResult = await this.ctx.model.Cart.findAll({
            where: {
                tableId: tableId,
                productId: productId
            }
        })
        if (cartResult.length > 0) {
            if (cartResult[0].productNum > 1) {
                this.ctx.model.Cart.update({
                    productNum: cartResult[0].productNum - 1
                }, {
                    where: {
                        tableId: tableId,
                        productId: productId
                    }
                });
            } else {
                this.ctx.model.Cart.destroy({
                    where: {
                        tableId: tableId,
                        productId: productId
                    }
                });
            }
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            this.ctx.body = { "success": false, "msg": "更新失败" };
        }
    }
    //获取购物车总数量
    async cartCount() {
        try {
            let tableId = this.ctx.request.query.tableId;

            let count = await this.ctx.model.Cart.sum(
                "productNum",
                { where: { tableId: tableId } }
            )
            count = count ? count : 0;
            this.ctx.body = { "success": true, count: count };

        } catch (error) {
            this.ctx.body = { "success": false, count: 0 };
        }

    }

    //获取口味信息
    async flavorList() {

        let result = await this.ctx.model.Setting.findAll();

        //少辣，不要葱，打包带走   ["少辣","不要葱"]
        let list = result[0].orderLabel.replace("，", ",").split(",");

        this.ctx.body = { "success": true, result: list };
    }

    //增加修改用户用餐信息
    async addPeopleInfo() {
        let body = this.ctx.request.body;
        let tableId = body.tableId;
        let result = await this.ctx.model.PeopleInfo.findAll({
            where: {
                tableId: tableId,
            }
        })
        if (result.length > 0) {
            await this.ctx.model.PeopleInfo.update(body, {
                where: {
                    tableId: tableId
                }
            })
            this.ctx.body = { "success": true, "msg": "更新成功" };
        } else {
            await this.ctx.model.PeopleInfo.create(body);
            this.ctx.body = { "success": true, "msg": "更新成功" };
        }
    }
    // 获取用户用餐信息
    async getPeopleInfo() {
        try {
            let tableId = this.ctx.request.query.tableId;
            let result = await this.ctx.model.PeopleInfo.findAll({
                where: {
                    tableId: tableId
                }
            })
            if (result.length > 0) {
                this.ctx.body = { "success": true, result: result[0] };
            } else {
                this.ctx.body = { "success": true, result: [] };
            }

        } catch (error) {
            this.ctx.body = { "success": false, result: [] };
        }
    }

}

module.exports = V1Controller;

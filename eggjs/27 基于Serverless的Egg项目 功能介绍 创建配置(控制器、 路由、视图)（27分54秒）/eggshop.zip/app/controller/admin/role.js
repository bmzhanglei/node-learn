'use strict';

const Controller = require('egg').Controller;

class RoleController extends Controller {
    async index() {
        this.ctx.body = "角色列表";
    }
    async add() {
        this.ctx.body = "角色 增加";
    }
    async edit() {
        this.ctx.body = "角色 修改";
    }
    async delete() {
        this.ctx.body = "角色 删除";
    }
}

module.exports = RoleController;

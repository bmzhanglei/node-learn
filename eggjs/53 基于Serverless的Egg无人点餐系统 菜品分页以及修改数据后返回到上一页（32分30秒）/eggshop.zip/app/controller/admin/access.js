'use strict';

const BaseController = require('./base.js');

class AccessController extends BaseController {
    async index() {
        // this.ctx.body = "权限列表";

        let result = await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            },
            include: { model: this.ctx.model.Access }
        });
        // this.ctx.body=result;
        await this.ctx.render("admin/access/index",{
            list:result
        });    
    }
    async add() {
        //获取moduleId=0的模块
        let accessList=await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            }
        })
        // console.log(accessResult);
        await this.ctx.render("admin/access/add",{
            accessList:accessList
        });       
    }
    async doAdd() {
        let addResult=this.ctx.request.body;
        if(addResult.moduleName==""){
            await this.error("模块名称不能为空",`/${this.config.adminPath}/access/add`);
            return;
        }
        await this.ctx.model.Access.create({
            ...addResult,
            status:1,
            addTime:this.ctx.service.tools.getUnixTime()
        })

        await this.success("增加权限成功",`/${this.config.adminPath}/access`);
    }
    async edit() {

        let id=this.ctx.request.query.id;
        let accessResult=await this.ctx.model.Access.findAll({
            where:{
                id:id
            }
        })
        //获取顶级模块
        let accessList=await this.ctx.model.Access.findAll({
            where:{
                moduleId:0
            }
        })

        await this.ctx.render("admin/access/edit",{
            access:accessResult[0],
            accessList:accessList
        });    
    }

    
    async doEdit() {
        let editResult=this.ctx.request.body;
        if(editResult.moduleName==""){
            await this.error("模块名称不能为空",`/${this.config.adminPath}/access/edit?id=${editResult.id}`);
            return;
        }
        let accessResult=await this.ctx.model.Access.findByPk(editResult.id);
        if(!accessResult){
            await this.error("非法请求",`/${this.config.adminPath}/access/edit?id=${editResult.id}`);
            return;
        }
        await accessResult.update(editResult);
        await this.success("修改权限成功",`/${this.config.adminPath}/access`);
    }
    async delete() {        
        let id=this.ctx.request.query.id;
        let accessResult=await this.ctx.model.Access.findAll({
            where:{
                id:id
            }
        });
        if(accessResult[0].moduleId!=0){
            let access=await this.ctx.model.Access.findByPk(id);
            if (!access) {
                await this.error("非法请求",`/${this.config.adminPath}/access/`);
                return;
            }
            await access.destroy();
            await this.success("删除数据成功",`/${this.config.adminPath}/access`);
        }else{
            //判断当前模块下面有没有菜单或者操作
            let subAccessResult=await this.ctx.model.Access.findAll({
                where:{
                    moduleId:id
                }
            });
            if(subAccessResult.length>0){
                //没法删除
                await this.error("当前模块下面还有菜单或者操作，没法删除，请删除菜单或者操作后重新删除",`/${this.config.adminPath}/access/`);
                return;
            }else{
                let access=await this.ctx.model.Access.findByPk(id);
                if (!access) {
                    await this.error("非法请求",`/${this.config.adminPath}/access/`);
                    return;
                }
                await access.destroy();
                await this.success("删除数据成功",`/${this.config.adminPath}/access`);
            }

        }
    }
}

module.exports = AccessController;

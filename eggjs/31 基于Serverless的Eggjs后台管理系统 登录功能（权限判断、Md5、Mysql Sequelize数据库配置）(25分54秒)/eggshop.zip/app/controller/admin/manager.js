'use strict';

const Controller = require('egg').Controller;

class ManagerController extends Controller {
  async index() {  
  
    //增加一条数据

    this.ctx.model.Admin.create({
      username:"admin",
      password:this.ctx.service.tools.md5("123456"),
      roleId:1,
      isSuper:1      
    })

    await this.ctx.render("admin/manager/index",{})
  }
  async add() {
    this.ctx.body=this.ctx.session.username;
    // await this.ctx.render("admin/manager/add",{})
  }
  async edit() {
    this.ctx.body="管理员 修改";
  }
  async delete() {
    this.ctx.body="管理员 删除";
  }
}

module.exports = ManagerController;

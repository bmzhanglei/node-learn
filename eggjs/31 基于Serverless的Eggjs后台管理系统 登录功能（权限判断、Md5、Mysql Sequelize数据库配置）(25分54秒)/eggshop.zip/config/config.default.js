/* eslint valid-jsdoc: "off" */

'use strict';

/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {
    env: 'prod',
    rundir: '/tmp',
    logger: {
      dir: '/tmp',
    },
  };

  config.session = {
    key: 'SESSION_ID_itying', 
    maxAge: 30*60*1000,   //如果过期时间比较长 建议保存在redis里面
    httpOnly: true, 
    encrypt: true,
    renew: true // 延长会话有效期    
 }

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1576384476895_3620';

    // add your middleware config here
    config.middleware = ["adminAuth"];
    config.adminAuth={
      match: '/admin',
    }

    // add your user config here
    const userConfig = {
      view: {
        mapping: {
          '.html': 'ejs',
        },
      }
    };

    //配置数据库    
    config.sequelize = {
      dialect: 'mysql',
      host: '192.168.0.14',
      port: 3306,
      username:"root", 
      password:"123456",
      database: 'eggshop',
    };

    return {
      ...config,
      ...userConfig,
    };
  };

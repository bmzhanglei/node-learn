/* eslint valid-jsdoc: "off" */

'use strict';

/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {
    env: 'prod',
    rundir: '/tmp',
    logger: {
      dir: '/tmp',
    },
  };
  //配置后台地址
  config.adminPath = 'admin';

  //配置文件上传的模式
  config.multipart = {
    mode: 'file',
  };

  config.uploadDir = "app/public/upload";

  //配置排除的地址
  config.ignoreUrl = [`/${config.adminPath}`, `/${config.adminPath}/welcome`, `/${config.adminPath}/login/loginOut`];
  
  //Cos域名 建议配置成自己的域名
  config.cosUrl = "https://itying-1251179943.cos.ap-beijing.myqcloud.com";

  //配置cos 
  config.cosObject={
    SecretId: 'AKID5ve8OOjIvJSLRJwITP6XiEUUFkhVJMvG',
    SecretKey: 'GF2KOnwoSrhGMDwPccNmGWWwfS0IqAJE',
    Bucket:"itying-1251179943",
    Region:"ap-beijing"
  }
  
  //配置session
  config.session = {
    key: 'SESSION_ID_itying',
    maxAge: 30 * 60 * 1000,   //如果过期时间比较长 建议保存在redis里面
    httpOnly: true,
    encrypt: true,
    renew: true // 延长会话有效期    
  }

  //配置csrf https://eggjs.org/zh-cn/core/security.html
  config.security = {
    csrf: {    
      ignore: ctx => {
        if (ctx.request.url == `/${config.adminPath}/product/doUpload`) {
          return true;
        }
        return false;
      },
    },
  }


  // 配置cooke key
  config.keys = appInfo.name + '_1576384476895_3620';

  // 配置中间件
  config.middleware = ["adminAuth"];
  config.adminAuth = {
    match: `/${config.adminPath}`,  //注意
    adminPath: config.adminPath,
    cosUrl: config.cosUrl
  }

  // add your user config here
  const userConfig = {
    view: {
      mapping: {
        '.html': 'ejs',
      },
    }
  };

  //配置数据库    
  config.sequelize = {
    dialect: 'mysql',
    host: '192.168.0.14',
    port: 3306,
    username: "root",
    password: "123456",
    database: 'eggshop',
  };

  return {
    ...config,
    ...userConfig,
  };
};

'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller, config } = app;

  router.get(`/api/v1`, controller.api.v1.index); 
  router.post(`/api/v1/addCart`, controller.api.v1.addCart); 
  router.get(`/api/v1/productList`, controller.api.v1.productList); 
  router.get(`/api/v1/productContent`, controller.api.v1.productContent); 
  
  
  router.get('/api/v1/cartList', controller.api.v1.cartList); 
  router.post('/api/v1/addCart', controller.api.v1.addCart); 
  router.put('/api/v1/incCart', controller.api.v1.incCart); 
  router.put('/api/v1/decCart', controller.api.v1.decCart); 
  router.get('/api/v1/cartCount', controller.api.v1.cartCount); 
  
  
};

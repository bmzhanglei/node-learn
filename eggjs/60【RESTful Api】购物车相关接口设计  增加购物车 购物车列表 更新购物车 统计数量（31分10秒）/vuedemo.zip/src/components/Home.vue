<template>
  <div class="home">
    <button @click="getProductData()">获取菜品数据</button>
    <br>
    <br>
    <button @click="addCart()">购物车增加数据</button>

    <br>
    <br>
    <button @click="getCartList()">获取购物车数据</button>
    <br>
    <br>

    <button @click="incCart()">增加购物车数量</button>

    <br>
    <br>

    <button @click="decCart()">减少购物车数量</button>
    
    <br>
    <br>

    <button @click="cartCount()">统计购物车数量</button>

    
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
    };
  },
  methods: {
    getProductData() {
      var api = "http://localhost:7001/api/v1/productList";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    addCart() {
      var api = "http://localhost:7001/api/v1/addCart";
      this.Axios.post(api, {     
        productTitle: "手撕包菜",         
        tableId: 10,      
        imgUrl:"www.itying.com",
        productPrice:12,
        productNum: 1,  
        productId: 12, 
      })
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getCartList() {
      var api = "http://localhost:7001/api/v1/cartList?tableId=12";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    incCart(){
      var api = "http://localhost:7001/api/v1/incCart";
      this.Axios.put(api,{productId:12,tableId:10})
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    decCart(){
      var api = "http://localhost:7001/api/v1/decCart";
      this.Axios.put(api,{productId:12,tableId:10})
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    cartCount(){
      var api = "http://localhost:7001/api/v1/cartCount?tableId=10";
      this.Axios.get(api)
        .then((response) => {
          console.log(response.data);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  },
};
</script>

<style lang="scss">
.home {
  padding: 20px;
}
</style>

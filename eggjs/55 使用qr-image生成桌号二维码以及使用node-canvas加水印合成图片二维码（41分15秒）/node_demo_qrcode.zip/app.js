const { createCanvas, Image } = require('canvas')
const fs = require('fs')

